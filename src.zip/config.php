<?php
define('db_host','localhost');
define('db_port','3306');
define('db','ctf');
define('db_user', 'root');
define('db_password','root');
?>