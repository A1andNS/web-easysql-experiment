<!--user login-->
<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Cache-Control" CONTENT="no-cache, must-revalidate">
    <META HTTP-EQUIV="Expires" CONTENT="0">
    <title>小龙的OS</title>
    <link rel="shortcut icon" href="./static/images/favicon_32.ico" sizes="32x32">
    <link rel="shortcut icon" href="./static/images/favicon_48.ico" sizes="48x48">
    <link href="./static/style/bootstrap.css?ver=TOS3_A1.0_4.2.17" rel="stylesheet"/>
    <link href="./static/style/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
          href="./static/style/new_login.css?ver=TOS3_A1.0_4.2.17">
    <link rel="stylesheet" type="text/css" href="/css/ctools.css?ver=TOS3_A1.0_4.2.17">
    <link rel="stylesheet" type="text/css" href="/js/layer/skin/default/layer.css?ver=TOS3_A1.0_4.2.17">
</head>
<body class="background" style="background-image:url(./static/images/wall_page/13.jpg)">
<div class="login-container">
    <div class="left">
        <div class="one">
            <h1 style="font-size:40px;">小龙的OS</h1>
            <div class="text">
                <p style="font-size:20px;">Welcome to</p>
                <p style="font-size:20px;">xiao long's</p>
                <p style="font-size:20px;">Operating System</p>
            </div>
        </div>
        <div class="two">
            <p>TEST_PRODUCT</p>
            <p>1.0</p>
        </div>
    </div>
    <div class="right">
        <form method="post" action="login.php" name="login">
        <div class="one">
            <!--			<p></p>-->
            <div class="login-box">
                <input id="username" name='name' type="text" placeholder="Username" required>
                <input id="password" name='password' type="password" placeholder="Password" required
                       class="password">
                <div class="remember">
                    <input type="checkbox" class="checkbox" mode="tos" name="rember_password"
                           id="rm">
                    <div style="flex:1;">Remember Me</div>
                </div>
                <div class="msg"></div>
                <button class="btn" id="submit">Login</button>
            </div>
        </div>
        <div class="two"></div>
        </form>
    </div>
</div>
<script src="./js/common.js></script>
<script src="./static/js/lib/seajs/sea.js?ver=TOS3_A1.0_4.2.17"></script>
<script src="./static/js/checkLowBrowser.js"></script>
<script type="text/javascript">
    var browser = getBrowserVersion(), L = {
        "Tips":"Suggerimenti",
        "browser":"Stai usando un browser non consigliato!",
        "browser_affect":"Continuare a utilizzare questo browser potrebbe causare una visualizzazione anomala o perfino un malfunzionamento della pagina TOS. Utilizza invece una versione recente dei browser consigliati di seguito."
    };
    seajs.config({
        base: "./static/js/",
        preload: ["jquery"],
        debug: true,
        map: [
            [/^(.*\.(?:css|js))(.*)$/i, '$1$2?ver=' + Math.random()]
        ]
    });
    seajs.use("app/src/user/main");
</script>
</body>
</html>