<?php
include("config.php");
class Mysql{
    /**
     * @var mysqli
     */
   public $conn;

    public function __construct(){
        $this->conn = new mysqli(db_host,db_user,db_password,db,db_port);
        if ($this->conn->connect_error) {
            die("Can't connect to database");
        }
        else{
            echo "<script>console.log('Connect Successfully');</script>";
            //echo db_host,db_user,db_password,db,db_port;
        }
    }
    function get_password($sql){
       $result =  $this->conn->query($sql);
       if($result->num_rows > 0){
            //echo "success".$result->num_rows;
           return mysqli_fetch_assoc($result)['PASSWORD'];
       }
       else{
        //    echo "false".$result->num_rows;
            die("用户不存在！");
       }
    //    echo var_dump($result);
    }
    function __destruct(){
        $this->conn->close();
        echo "<script>console.log('Connect closed');</script>";
    }
}
// $mysql = new Mysql($db_host,$db_user,$db_password,$db,$db_port);
// $name = "admin";
// $password = "207d2a90782cdcb76acc4b181c9cb0d9";
// $sql = "SELECT * FROM `admin` WHERE USER='".$name."' and PASSWORD='".$password."'";
// $mysql->check_login($sql);

?>