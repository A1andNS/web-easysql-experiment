<?php
function filter($arg){
    $arg = preg_replace('/and|or|if|distinct|order|sleep|count|like/i', '', $arg);
    $ismatched = preg_match('/select|union|where|#|%|\^|-|\+|\||\s/',$arg);
    if ($ismatched){
        header("refresh:3;url=index.php");
        die("存在敏感参数！！！");
    }
    else{
        return $arg;
    }
}