function getBrowserVersion() {
    var agent = navigator.userAgent.toLowerCase(),
        opera = window.opera,
        browser = {
            //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁涓篒E
            ie: /(msie\s|trident.*rv:)([\w.]+)/.test(agent),
            //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁涓篛pera
            opera: (!!opera && opera.version),
            //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁鏄痺ebkit鍐呮牳鐨勬祻瑙堝櫒
            webkit: (agent.indexOf(' applewebkit/') > -1),
            //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁鏄繍琛屽湪mac骞冲彴涓�
            mac: (agent.indexOf('macintosh') > -1),
            //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁澶勪簬鈥滄€紓妯″紡鈥濅笅
            quirks: (document.compatMode == 'BackCompat')
        };
    //妫€娴嬪綋鍓嶆祻瑙堝櫒鍐呮牳鏄惁鏄痝ecko鍐呮牳
    browser.gecko = (navigator.product == 'Gecko' && !browser.webkit && !browser.opera && !browser.ie);
    var version = 0;
    // Internet Explorer 6.0+
    if (browser.ie) {
        var v1 = agent.match(/(?:msie\s([\w.]+))/);
        var v2 = agent.match(/(?:trident.*rv:([\w.]+))/);
        if (v1 && v2 && v1[1] && v2[1]) {
            version = Math.max(v1[1] * 1, v2[1] * 1);
        } else if (v1 && v1[1]) {
            version = v1[1] * 1;
        } else if (v2 && v2[1]) {
            version = v2[1] * 1;
        } else {
            version = 0;
        }
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE11 鍏煎妯″紡
        browser.ie11Compat = document.documentMode == 11;
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE9 鍏煎妯″紡
        browser.ie9Compat = document.documentMode == 9;
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE10 鍏煎妯″紡
        browser.ie10Compat = document.documentMode == 10;
        //妫€娴嬫祻瑙堝櫒鏄惁鏄疘E8娴忚鍣�
        browser.ie8 = !!document.documentMode;
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE8 鍏煎妯″紡
        browser.ie8Compat = document.documentMode == 8;
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE7 鍏煎妯″紡
        browser.ie7Compat = ((version == 7 && !document.documentMode) || document.documentMode == 7);
        //妫€娴嬫祻瑙堝櫒妯″紡鏄惁涓� IE6 妯″紡 鎴栬€呮€紓妯″紡
        browser.ie6Compat = (version < 7 || browser.quirks);
        browser.ie9above = version > 8;
        browser.ie9below = version < 9;
    }
    // Gecko.
    if (browser.gecko) {
        var geckoRelease = agent.match(/rv:([\d\.]+)/);
        if (geckoRelease) {
            geckoRelease = geckoRelease[1].split('.');
            version = geckoRelease[0] * 10000 + (geckoRelease[1] || 0) * 100 + (geckoRelease[2] || 0) * 1;
        }
    }
    //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁涓篊hrome, 濡傛灉鏄紝鍒欒繑鍥濩hrome鐨勫ぇ鐗堟湰鍙�
    if (/chrome\/(\d+\.\d)/i.test(agent)) {
        browser.chrome = +RegExp['\x241'];
    }
    //妫€娴嬪綋鍓嶆祻瑙堝櫒鏄惁涓篠afari, 濡傛灉鏄紝鍒欒繑鍥濻afari鐨勫ぇ鐗堟湰鍙�
    if (/(\d+\.\d)?(?:\.\d)?\s+safari\/?(\d+\.\d+)?/i.test(agent) && !/chrome/i.test(agent)) {
        browser.safari = +(RegExp['\x241'] || RegExp['\x242']);
    }
    // Opera 9.50+
    if (browser.opera)
        version = parseFloat(opera.version());
    // WebKit 522+ (Safari 3+)
    if (browser.webkit)
        version = parseFloat(agent.match(/ applewebkit\/(\d+)/)[1]);
    //妫€娴嬪綋鍓嶆祻瑙堝櫒鐗堟湰鍙�
    browser.version = version;
    return browser;
}