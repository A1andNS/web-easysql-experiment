<?php
include("mysql.php");
include("waf.php");
$name = $_POST['name'];
$password = $_POST['password'];
if (!isset($_POST['name']) or !isset($_POST['password'])){
    echo "未输入账号或密码!";
    header("Refresh:3;url=index.php");
    die();
}
$name = filter($name);
$password = filter($password);
$sql = "SELECT PASSWORD FROM `admin` WHERE USER='".$name."'";
// echo $sql;
$mysql = new MySql();
$result = $mysql->get_password($sql);
if ($result === $password){
    echo "3秒跳转";
    setcookie("user", "96a33bb88bf2758cc306d7f6602be0de",time()+3600);
    header("refresh:3;url=flll1111lll4g.php");
}
else{
    echo "账号或密码错误！";
    header("refresh:3;url=index.php");
}
